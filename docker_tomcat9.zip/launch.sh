#!/bin/bash


function startSshd() {
    /usr/sbin/sshd -D
}


function startTomcat() {
    /usr/share/tomcat/bin/catalina.sh run
}

# fonction qui maintient la session ouverte
function keepOpenSession() {
    while :; do :; done & kill -STOP $! && wait $!
}


startSshd &
startTomcat
# keepOpenSession


