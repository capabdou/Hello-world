#!/bin/sh

packer build build.pkr.hcl
