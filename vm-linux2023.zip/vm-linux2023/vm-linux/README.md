# Machine Virtuelle Locale de developpement

Le but de ces scripts est de créer et d'utiliser une VM linux dédié au développeur. La VM se base sur la version d'Ubuntu LTS 22.04. Elle installe
tout les programmes et script nécessaire à l'utilisation d'un poste de developpeur dans le département digital de Swisslife.

## Les outils intégrés dans la VM

Liste non exaustifs des outils intégrés dans la VM:

- Développement
  - Git
  - VSCode (avec quelques extensions de bases)
  - Postman
  - Navigateurs
    - Chrome
    - Chromium
    - Firefox
  - GraphQL Playground
  - Langage
    - Java (avec maven)
    - Python
    - Node (via nvm via oh-my-zsh)
    - PlantUML
- Ops

  - Docker
  - AWS Cli
  - AWS-ADFS
  - mycli
  - mysql-server
  - sqlite
  - pdftk
  - vagrant

- Système

  - Ubuntu 22.04 ...
  - Htop
  - Aptitude
  - jq
  - rsync
  - zsh (oh-my-zsh)
  - curl
  - dos2unix
  - nano
  - putty
  - screen

- Confort
  - Filelight
  - Yakuake
  - Gimp

## Pré-requis

- Avoir le proxy McAffee installé sur son poste
- Pour une utilisation avec vagrant
  - Installer Vagrant: [https://www.vagrantup.com/downloads](https://www.vagrantup.com/downloads)
  - Installer VirtualBox: [https://www.virtualbox.org/wiki/Downloads](https://www.virtualbox.org/wiki/Downloads)
  - Télécharger l'image ici : [https://slfr.sharepoint.com/:f:/s/GRP_DSI_DDE_Digital/Ep4zol3rAKhDiJpVgr6QYWcBppopuLLoIFTMnBEUt4oX8g?e=E87SNC](https://slfr.sharepoint.com/:f:/s/GRP_DSI_DDE_Digital/Ep4zol3rAKhDiJpVgr6QYWcBppopuLLoIFTMnBEUt4oX8g?e=E87SNC)
  - Où l'image suivante sans l'interface graphique :

## Utilisation

### Avec WSL

Sur WSL, l'installation n'ajoute que les outils qui n'ont pas de GUI. Les logiciels avec GUI doivent être installé à la main.

Pour lancer les commandes dans WSL:

```bash
apt update
apt install git
git clone https://bitbucket.swisslife.fr/scm/fdout/vm-linux.git
cd vm-linux
./scripts/setup_wsl.sh
```

### Avec Vagrant

Pour lancer le projet avec Vagrant, il faut cloner le projet et lancer vagrant dans le dossier
du projet

```bash
git clone https://bitbucket.swisslife.fr/scm/fdout/vm-linux.git
cd vm-linux
# Déposer l'image téléchargé depuis sharepoint dans le dossier builds
mkdir ./builds
cp ~/Téléchargement/swl-ubuntu.box ./builds/swl-ubuntu.box
vagrant up
```

Vagrant créera la VM à partir la Vagrant Box et provisionnera la VM avec les dernières évolutions et les
mise à jour.

Une fois terminée, vous pouvez utiliser la VM sans Vagrant.

Si vous avez besoin de mettre à jour la VM avec les derniers nouveauté du repo vm-linux :

```bash
# VM éteinte
cd vm-linux
git pull
vagrant up --provision

# VM allumé
git pull
vagrant provision
```

En cas de gros problème avec la VM vous pouver lancer la commande `vagrant destroy`. Cela détruira entièrement la VM
et tout son contenu. Pensez à faire une sauvegarde des fichiers modifié (par exemple `/home`) avant de la détruire.

### Sans Vagrant.

Télécharger la box `swl-ubuntu.box`.

Décompresser avec `7z` le fichier (le fichier doit être décompressé, puis une seconde fois dé-taré). Avec tar :

```bash
tar xf swl-ubuntu.box
```

Utiliser l'outil d'importation pour importer le fichier box.ovf

```bash
vboxmanage import box.ovf
```

Renommé votre VM.

### Utilisation de la VM

- Le login et le mot de passe de la VM sont `vagrant`.
- Lors du démarrage des consoles linux, oh-my-zsh vous demandera de configure votre environnement.
- Vous pouvez également configurer les polices utilisés si vous avez des problèmes d'affichage dans votre terminal.

## Regénérer des outils

Si vous souhaitez modifier l'image de base de génération de VM pour par exemple y ajouter ou supprimer des outils, cette section est faite pour vous.

### Pré-requis pour la génération

- Avoir le proxy full-cloud installé sur son poste (pas le proxy hybrid)
- Installer Vagrant: [https://www.vagrantup.com/downloads](https://www.vagrantup.com/downloads)
- Installer VirtualBox: [https://www.virtualbox.org/wiki/Downloads](https://www.virtualbox.org/wiki/Downloads)
- Installer Packer: [https://www.packer.io/downloads](https://www.packer.io/downloads)

### Démarche

L'image de base est construite à l'aide Packer et Ansible. Pour ajouter, supprimer des logiciels dans l'image de base, il faut modifier les scripts
ansible du dossier ansible.

- `packer.yml` est appelé pour mettre les outils nécessaires à la construction d'une imapge avec packer.
- `application.yml` est appelé pour installer tout l'environnement de travail.

Le script application.yml est également utilisé lors du provisionning de la VM avec Vagrant.

Une fois les scripts modifiés, lancé la commande suivante dans le dossier racine du projet:

```bash
packer build build.json
```

Une fois la commande terminée avec succés la box se trouve dans le dossier builds.

### Sauvegarde

La VM utilise borg pour sauvegarder automatiquement votre dossier /home (exclus des node_modules et du cache angular)
dans le dossier /home/vagrant/borg.

Pour restaurer une sauvegarde, il faut lancer la commande suivante depuis une VM Linux fraichement démarrée:

```bash
borg extract /vagrant/borg::vm-home
```
