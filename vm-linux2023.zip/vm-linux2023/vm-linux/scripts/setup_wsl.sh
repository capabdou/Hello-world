#!/bin/bash -eux

# Install Ansible repository.
sudo apt -y update
sudo apt-get -y upgrade
sudo apt -y install ansible

# Call ansible
cd ansible
ansible-galaxy install -r requirements.yml
ansible-playbook -i localhost, -c local -e username=`whoami` application.yml